import streamlit as st

st.set_page_config(
    page_title="📚 Library Management System",
    page_icon="📚",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Shared CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    /* Global font */
    html, body, [class*="css"] { font-family: 'Segoe UI', sans-serif; }

    /* Sidebar */
    section[data-testid="stSidebar"] {
        background: linear-gradient(180deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
        color: white;
    }
    section[data-testid="stSidebar"] * { color: white !important; }
    section[data-testid="stSidebar"] .stButton > button {
        width: 100%;
        background: rgba(255,255,255,0.08);
        border: 1px solid rgba(255,255,255,0.15);
        color: white !important;
        border-radius: 8px;
        margin-bottom: 4px;
        text-align: left;
        padding: 10px 16px;
        transition: background 0.2s;
    }
    section[data-testid="stSidebar"] .stButton > button:hover {
        background: rgba(255,255,255,0.18);
    }

    /* Cards */
    .kpi-card {
        background: white;
        border-radius: 12px;
        padding: 20px 24px;
        box-shadow: 0 2px 12px rgba(0,0,0,0.08);
        border-left: 5px solid #0f3460;
        margin-bottom: 16px;
    }
    .kpi-card h2 { margin: 0; font-size: 2rem; color: #0f3460; }
    .kpi-card p  { margin: 0; color: #666; font-size: 0.9rem; }

    /* Page header */
    .page-header {
        background: linear-gradient(135deg, #0f3460, #533483);
        color: white;
        padding: 22px 28px;
        border-radius: 12px;
        margin-bottom: 24px;
    }
    .page-header h1 { margin: 0; font-size: 1.7rem; }
    .page-header p  { margin: 4px 0 0; opacity: 0.85; font-size: 0.95rem; }

    /* Streamlit metric override */
    div[data-testid="metric-container"] {
        background: white;
        border-radius: 10px;
        padding: 16px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.07);
    }

    /* Tables */
    .stDataFrame { border-radius: 8px; overflow: hidden; }

    /* Success / error */
    .stAlert { border-radius: 8px; }
</style>
""", unsafe_allow_html=True)

# ── Session defaults ──────────────────────────────────────────────────────────
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
if "role" not in st.session_state:
    st.session_state.role = None          # "admin" | "member"
if "user_id" not in st.session_state:
    st.session_state.user_id = None
if "user_name" not in st.session_state:
    st.session_state.user_name = ""
if "page" not in st.session_state:
    st.session_state.page = "login"

# ── Router ────────────────────────────────────────────────────────────────────
def goto(page):
    st.session_state.page = page
    st.rerun()

def logout():
    for k in ["logged_in", "role", "user_id", "user_name"]:
        st.session_state[k] = None if k != "logged_in" else False
    st.session_state.page = "login"
    st.rerun()

# ── Sidebar navigation ────────────────────────────────────────────────────────
def render_sidebar():
    with st.sidebar:
        st.markdown("## 📚 Library System")
        st.markdown(f"👤 **{st.session_state.user_name}**")
        st.markdown(f"🔖 Role: `{st.session_state.role}`")
        st.markdown("---")

        if st.session_state.role == "admin":
            nav_items = [
                ("🏠 Dashboard",     "dashboard"),
                ("📖 Add New Book",  "add_book"),
                ("🔄 Transactions",  "transactions"),
                ("ℹ️ Information",   "information"),
                ("📊 Analytics",     "analytics"),
            ]
        else:
            nav_items = [
                ("🏠 Dashboard",    "dashboard"),
                ("🔄 Transactions", "transactions"),
                ("ℹ️ Information",  "information"),
            ]

        for label, page in nav_items:
            if st.button(label, key=f"nav_{page}"):
                goto(page)

        st.markdown("---")
        if st.button("🚪 Logout"):
            logout()

# ── Page dispatcher ───────────────────────────────────────────────────────────
page = st.session_state.page

if not st.session_state.logged_in or page == "login":
    from pages.login import render
    render()
else:
    render_sidebar()
    if page == "dashboard":
        from pages.dashboard import render
        render()
    elif page == "add_book":
        from pages.add_book import render
        render()
    elif page == "transactions":
        from pages.transactions import render
        render()
    elif page == "information":
        from pages.information import render
        render()
    elif page == "analytics":
        from pages.analytics import render
        render()
    else:
        from pages.dashboard import render
        render()
