import mysql.connector
from mysql.connector import Error
import streamlit as st

DB_CONFIG = {
    "host": "127.0.0.1",
    "port": 3306,
    "user": "root",
    "password": "Suriya@14",
    "database": "mybala",
    "charset": "utf8mb4",
    "autocommit": False,
}


def get_connection():
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        return conn
    except Error as e:
        st.error(f"❌ Database connection failed: {e}")
        return None


def run_query(query, params=None, fetch=True):
    conn = get_connection()
    if conn is None:
        return None
    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute(query, params or ())
        if fetch:
            result = cursor.fetchall()
            cursor.close()
            conn.close()
            return result
        else:
            conn.commit()
            affected = cursor.rowcount
            last_id = cursor.lastrowid
            cursor.close()
            conn.close()
            return {"affected": affected, "last_id": last_id}
    except Error as e:
        try:
            conn.rollback()
        except Exception:
            pass
        st.error(f"❌ Query error: {e}")
        return None
