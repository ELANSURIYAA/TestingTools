import streamlit as st
from db import run_query
from datetime import date, timedelta
import pandas as pd

FINE_PER_DAY = 10.00   # ₹ 10 per day overdue
DUE_DAYS     = 15      # 15-day lending period


def render():
    st.markdown("""
    <div class="page-header">
        <h1>🔄 Transactions</h1>
        <p>Issue books to members and process returns — fines calculated automatically</p>
    </div>
    """, unsafe_allow_html=True)

    tab_issue, tab_return, tab_history = st.tabs(["📤 Issue Book", "📥 Return Book", "📋 Transaction History"])

    # ════════════════════════════════════════════════════════════════════════
    # TAB 1 — Issue Book
    # ════════════════════════════════════════════════════════════════════════
    with tab_issue:
        if st.session_state.role != "admin":
            st.warning("⚠️ Only admins can issue books.")
        else:
            st.markdown("### 📤 Issue a Book to a Member")

            # Live member search
            col1, col2 = st.columns(2)
            member_search = col1.text_input("🔍 Search Member (name / email / phone)")
            book_search   = col2.text_input("🔍 Search Book (title / author / ISBN)")

            members = []
            if member_search:
                members = run_query("""
                    SELECT m.member_id,
                           CONCAT(m.first_name,' ',m.last_name) AS name,
                           m.email, m.phone,
                           p.plan_name, ms.plan_end_date,
                           p.max_books,
                           (SELECT COUNT(*) FROM transactions t
                            WHERE t.member_id=m.member_id AND t.status='issued') AS books_out
                    FROM members m
                    LEFT JOIN memberships ms ON ms.member_id=m.member_id
                    LEFT JOIN membership_plans p ON p.plan_id=ms.plan_id
                    WHERE m.status='active'
                      AND (m.first_name LIKE %s OR m.last_name LIKE %s
                           OR m.email LIKE %s OR m.phone LIKE %s)
                    LIMIT 10
                """, (f"%{member_search}%",)*4)

            books = []
            if book_search:
                books = run_query("""
                    SELECT book_id, title, author, isbn, shelf_location, status
                    FROM books
                    WHERE status='available'
                      AND (title LIKE %s OR author LIKE %s OR isbn LIKE %s)
                    LIMIT 10
                """, (f"%{book_search}%",)*3)

            with st.form("issue_form"):
                if members:
                    mem_opts = {
                        f"[{m['member_id']}] {m['name']} | {m['email']} | Plan: {m.get('plan_name','None')}": m
                        for m in members
                    }
                    sel_mem_key = st.selectbox("Select Member *", list(mem_opts.keys()))
                    sel_mem     = mem_opts[sel_mem_key]
                else:
                    st.info("🔍 Search a member above to continue.")
                    sel_mem = None

                if books:
                    book_opts = {
                        f"[{b['book_id']}] {b['title']} — {b['author']} | Shelf: {b.get('shelf_location','?')}": b
                        for b in books
                    }
                    sel_book_key = st.selectbox("Select Book *", list(book_opts.keys()))
                    sel_book     = book_opts[sel_book_key]
                else:
                    st.info("🔍 Search an available book above to continue.")
                    sel_book = None

                issue_date = st.date_input("Issue Date *", value=date.today())
                due_date   = issue_date + timedelta(days=DUE_DAYS)
                st.info(f"📅 Return Due Date: **{due_date.strftime('%d %B %Y')}** (15 days)")
                notes      = st.text_input("Notes (optional)")

                submitted = st.form_submit_button("📤 Issue Book", use_container_width=True)

            if submitted:
                if not sel_mem or not sel_book:
                    st.error("❌ Please select both a member and a book.")
                else:
                    # Validate membership
                    if sel_mem.get("plan_end_date") and sel_mem["plan_end_date"] < date.today():
                        st.error("❌ Member's membership has expired. Renew before issuing.")
                    elif sel_mem.get("max_books") and sel_mem["books_out"] >= sel_mem["max_books"]:
                        st.error(f"❌ Member has reached max book limit ({sel_mem['max_books']}).")
                    else:
                        res = run_query("""
                            INSERT INTO transactions (member_id, book_id, issue_date, due_date, status, notes)
                            VALUES (%s, %s, %s, %s, 'issued', %s)
                        """, (sel_mem["member_id"], sel_book["book_id"],
                              issue_date, due_date, notes or None), fetch=False)

                        if res and res["affected"]:
                            run_query("UPDATE books SET status='issued' WHERE book_id=%s",
                                      (sel_book["book_id"],), fetch=False)
                            st.success(f"""
                            ✅ Book issued successfully!
                            - **Member:** {sel_mem['name']}
                            - **Book:** {sel_book['title']}
                            - **Due Date:** {due_date.strftime('%d %B %Y')}
                            """)
                            st.rerun()
                        else:
                            st.error("❌ Failed to issue book.")

    # ════════════════════════════════════════════════════════════════════════
    # TAB 2 — Return Book
    # ════════════════════════════════════════════════════════════════════════
    with tab_return:
        st.markdown("### 📥 Return a Book")

        role = st.session_state.role
        if role == "admin":
            search_term = st.text_input("🔍 Search by Member Name / ID / Book Title")
            if search_term:
                issues = run_query("""
                    SELECT t.transaction_id,
                           CONCAT(m.first_name,' ',m.last_name) AS member_name,
                           m.member_id, b.title, b.book_id,
                           t.issue_date, t.due_date,
                           GREATEST(0, DATEDIFF(CURDATE(), t.due_date)) AS overdue_days,
                           GREATEST(0, DATEDIFF(CURDATE(), t.due_date)) * %s AS fine_amount
                    FROM transactions t
                    JOIN members m ON m.member_id=t.member_id
                    JOIN books   b ON b.book_id=t.book_id
                    WHERE t.status='issued'
                      AND (m.first_name LIKE %s OR m.last_name LIKE %s
                           OR CAST(m.member_id AS CHAR) LIKE %s
                           OR b.title LIKE %s)
                    ORDER BY t.due_date
                """, (FINE_PER_DAY, f"%{search_term}%", f"%{search_term}%",
                       f"%{search_term}%", f"%{search_term}%"))
            else:
                issues = run_query("""
                    SELECT t.transaction_id,
                           CONCAT(m.first_name,' ',m.last_name) AS member_name,
                           m.member_id, b.title, b.book_id,
                           t.issue_date, t.due_date,
                           GREATEST(0, DATEDIFF(CURDATE(), t.due_date)) AS overdue_days,
                           GREATEST(0, DATEDIFF(CURDATE(), t.due_date)) * %s AS fine_amount
                    FROM transactions t
                    JOIN members m ON m.member_id=t.member_id
                    JOIN books   b ON b.book_id=t.book_id
                    WHERE t.status='issued'
                    ORDER BY t.due_date LIMIT 50
                """, (FINE_PER_DAY,))
        else:
            # Member sees only their own
            issues = run_query("""
                SELECT t.transaction_id,
                       CONCAT(m.first_name,' ',m.last_name) AS member_name,
                       m.member_id, b.title, b.book_id,
                       t.issue_date, t.due_date,
                       GREATEST(0, DATEDIFF(CURDATE(), t.due_date)) AS overdue_days,
                       GREATEST(0, DATEDIFF(CURDATE(), t.due_date)) * %s AS fine_amount
                FROM transactions t
                JOIN members m ON m.member_id=t.member_id
                JOIN books   b ON b.book_id=t.book_id
                WHERE t.status='issued' AND t.member_id=%s
                ORDER BY t.due_date
            """, (FINE_PER_DAY, st.session_state.user_id))

        if issues:
            # Show summary table
            df = pd.DataFrame(issues)
            df_display = df[["transaction_id","member_name","title","issue_date","due_date","overdue_days","fine_amount"]].copy()
            df_display.columns = ["Txn ID","Member","Book","Issue Date","Due Date","Overdue Days","Fine (₹)"]
            st.dataframe(df_display, use_container_width=True, hide_index=True)

            st.markdown("---")
            st.markdown("#### ✅ Process Return")
            txn_opts = {
                f"[{r['transaction_id']}] {r['member_name']} — {r['title']} | Fine: ₹{r['fine_amount']:.2f}": r
                for r in issues
            }
            sel_txn_key = st.selectbox("Select Transaction to Return", list(txn_opts.keys()))
            sel_txn     = txn_opts[sel_txn_key]

            # Fine summary
            fine = float(sel_txn["fine_amount"] or 0)
            overdue = int(sel_txn["overdue_days"] or 0)
            if fine > 0:
                st.error(f"⚠️ Fine: **₹{fine:.2f}** ({overdue} days × ₹{FINE_PER_DAY}/day)")
            else:
                st.success("✅ No fine — returned on time!")

            col_r1, col_r2 = st.columns(2)
            return_date = col_r1.date_input("Return Date", value=date.today())
            fine_paid   = col_r2.checkbox("Fine Collected?", value=(fine == 0))

            if st.button("📥 Confirm Return", use_container_width=True):
                run_query("""
                    UPDATE transactions
                    SET status='returned', return_date=%s,
                        fine_amount=%s, fine_paid=%s
                    WHERE transaction_id=%s
                """, (return_date, fine, 1 if fine_paid else 0,
                      sel_txn["transaction_id"]), fetch=False)
                run_query("UPDATE books SET status='available' WHERE book_id=%s",
                          (sel_txn["book_id"],), fetch=False)
                st.success(f"✅ Book returned successfully! Fine: ₹{fine:.2f}")
                st.rerun()
        else:
            st.info("📭 No active issues found.")

    # ════════════════════════════════════════════════════════════════════════
    # TAB 3 — Transaction History
    # ════════════════════════════════════════════════════════════════════════
    with tab_history:
        st.markdown("### 📋 Transaction History")

        col_f1, col_f2, col_f3 = st.columns(3)
        filter_status = col_f1.selectbox("Status", ["All","issued","returned","lost"])
        date_from     = col_f2.date_input("From", value=date.today() - timedelta(days=30))
        date_to       = col_f3.date_input("To",   value=date.today())

        base = """
            SELECT t.transaction_id,
                   CONCAT(m.first_name,' ',m.last_name) AS member,
                   b.title, t.issue_date, t.due_date, t.return_date,
                   t.status, t.fine_amount, t.fine_paid
            FROM transactions t
            JOIN members m ON m.member_id=t.member_id
            JOIN books   b ON b.book_id=t.book_id
            WHERE t.issue_date BETWEEN %s AND %s
        """
        params = [date_from, date_to]
        if st.session_state.role == "member":
            base   += " AND t.member_id=%s"
            params.append(st.session_state.user_id)
        if filter_status != "All":
            base   += " AND t.status=%s"
            params.append(filter_status)
        base += " ORDER BY t.transaction_id DESC LIMIT 300"

        rows = run_query(base, tuple(params))
        if rows:
            df = pd.DataFrame(rows)
            df.columns = ["Txn ID","Member","Book","Issue Date","Due Date","Return Date","Status","Fine (₹)","Fine Paid"]
            st.dataframe(df, use_container_width=True, hide_index=True)
            st.caption(f"Total records: {len(df)}")
        else:
            st.info("📭 No transactions found for selected filters.")
