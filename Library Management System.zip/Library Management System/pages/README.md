# 📚 Library Management System
### Built with Python · Streamlit · MySQL

---

## 📁 Project Structure

```
Library Management System/
│
├── app.py                  ← Main entry point (run this)
├── db.py                   ← MySQL connection & query helper
├── requirements.txt        ← Python dependencies
├── ddl.sql                 ← Full database schema + sample data
│
└── pages/
    ├── __init__.py
    ├── login.py            ← Admin Login | Member Login | Sign-Up
    ├── dashboard.py        ← Home dashboard (KPIs, overdue, quick actions)
    ├── add_book.py         ← Add new books from vendor, manage catalogue
    ├── transactions.py     ← Issue books, return books, fine calculation
    ├── information.py      ← Book catalogue, member directory, memberships
    └── analytics.py        ← Charts, KPIs, trends, overdue analysis
```

---

## ⚙️ Setup Instructions

### Step 1 — Set up the Database

1. Open **MySQL Workbench** (or any MySQL client)
2. Connect to: `127.0.0.1:3306` as `root`
3. Open `ddl.sql` and run the entire script
4. This creates all 7 tables + views + sample data

### Step 2 — Install Python Dependencies

Open **Command Prompt** or **PowerShell** and run:

```bash
cd "C:\Users\elansuriyaa.p\Downloads\Library Management System"
pip install -r requirements.txt
```

### Step 3 — Run the App

```bash
streamlit run app.py
```

The app will open at: **http://localhost:8501**

---

## 🔐 Default Login

| Role  | Field    | Value       |
|-------|----------|-------------|
| Admin | Username | `admin`     |
| Admin | Password | `admin123`  |

For **Member Login**, use the email + phone you registered with.

---

## 📄 Pages Overview

| Page           | Access       | Description |
|----------------|--------------|-------------|
| Login          | All          | Admin login, Member login, New member sign-up |
| Dashboard      | All          | KPIs, overdue list, quick actions, assign memberships |
| Add New Book   | Admin only   | Add books by vendor, filter catalogue, update status |
| Transactions   | Admin + Member | Issue books (15-day due), return books, fine (₹10/day) |
| Information    | Admin + Member | Book catalogue, member directory, membership status |
| Analytics      | Admin only   | Bar/Pie/Line charts, KPIs, top books, fine trends |

---

## 💡 Key Business Rules

- **Due period:** 15 days from issue date
- **Fine:** ₹10 per overdue day
- **Membership** limits max books a member can borrow simultaneously
- Admin can assign / update membership plans from the Dashboard
- Member status (active / inactive / suspended) controls access

---

## 🗄️ Database Schema

| Table             | Purpose |
|-------------------|---------|
| admins            | Admin users with SHA-256 passwords |
| categories        | Book genre/category list |
| books             | Library catalogue |
| members           | Registered library members |
| membership_plans  | Plan types (Basic, Standard, Premium) |
| memberships       | Member ↔ Plan assignment |
| transactions      | Book issue & return log with fines |

Views: `v_active_issues`, `v_member_plans`
