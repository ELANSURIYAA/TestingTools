import streamlit as st
from db import run_query


def render():
    if st.session_state.role != "admin":
        st.warning("⚠️ Only admins can access this page.")
        return

    st.markdown("""
    <div class="page-header">
        <h1>📖 Add New Book</h1>
        <p>Register a new book received from a vendor into the library catalogue</p>
    </div>
    """, unsafe_allow_html=True)

    tab_add, tab_list = st.tabs(["➕ Add New Book", "📋 Book Catalogue"])

    # ── Add Book Form ─────────────────────────────────────────────────────────
    with tab_add:
        st.markdown("#### 📦 New Book Entry")
        categories = run_query("SELECT category_id, category_name FROM categories ORDER BY category_name")
        cat_map    = {c["category_name"]: c["category_id"] for c in (categories or [])}

        with st.form("add_book_form", clear_on_submit=True):
            st.markdown("**📌 Required Fields**")
            c1, c2 = st.columns(2)
            title  = c1.text_input("Book Title *",    placeholder="e.g. The Alchemist")
            author = c2.text_input("Author Name *",   placeholder="e.g. Paulo Coelho")

            c3, c4 = st.columns(2)
            isbn   = c3.text_input("ISBN",            placeholder="978-3-16-148410-0")
            publisher = c4.text_input("Publisher",    placeholder="e.g. HarperCollins")

            c5, c6, c7 = st.columns(3)
            pub_year   = c5.number_input("Publication Year", min_value=1800, max_value=2100, value=2024, step=1)
            category   = c6.selectbox("Category *",  list(cat_map.keys()))
            shelf_loc  = c7.text_input("Shelf Location", placeholder="e.g. A-12")

            st.markdown("**📝 Additional Details**")
            description = st.text_area("Book Description / Notes", placeholder="Brief description of the book...")

            c8, c9 = st.columns(2)
            vendor_name  = c8.text_input("Vendor / Supplier Name", placeholder="e.g. Sapna Book House")
            vendor_invoice = c9.text_input("Vendor Invoice No.",   placeholder="INV-2024-001")

            quantity = st.number_input("Number of Copies to Add *", min_value=1, max_value=50, value=1, step=1)

            submitted = st.form_submit_button("📚 Add Book(s) to Library", use_container_width=True)

        if submitted:
            if not title.strip() or not author.strip():
                st.error("❌ Title and Author are required fields.")
            else:
                success_count = 0
                for _ in range(quantity):
                    res = run_query(
                        """INSERT INTO books
                               (title, author, isbn, publisher, publication_year,
                                category_id, shelf_location, description, status)
                           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,'available')""",
                        (
                            title.strip(), author.strip(),
                            isbn.strip()       or None,
                            publisher.strip()  or None,
                            int(pub_year),
                            cat_map[category],
                            shelf_loc.strip()  or None,
                            description.strip() or None,
                        ),
                        fetch=False,
                    )
                    if res and res["affected"]:
                        success_count += 1

                if success_count == quantity:
                    st.success(f"✅ {success_count} copy/copies of **{title}** added successfully!")
                    if vendor_name:
                        st.info(f"📦 Vendor: {vendor_name} | Invoice: {vendor_invoice or 'N/A'}")
                else:
                    st.warning(f"⚠️ Added {success_count}/{quantity} copies. Check for errors.")

    # ── Book Catalogue ────────────────────────────────────────────────────────
    with tab_list:
        st.markdown("#### 📋 Library Catalogue")

        col_s, col_f, col_cat = st.columns(3)
        search  = col_s.text_input("🔍 Search by Title / Author")
        filter_status = col_f.selectbox("Status Filter", ["All", "available", "issued", "lost", "maintenance"])
        categories2   = run_query("SELECT category_name FROM categories ORDER BY category_name")
        cat_names     = ["All"] + [c["category_name"] for c in (categories2 or [])]
        filter_cat    = col_cat.selectbox("Category Filter", cat_names)

        query  = """
            SELECT b.book_id, b.title, b.author, b.isbn,
                   b.publisher, b.publication_year,
                   c.category_name, b.shelf_location, b.status, b.added_on
            FROM books b
            LEFT JOIN categories c ON c.category_id = b.category_id
            WHERE 1=1
        """
        params = []
        if search:
            query += " AND (b.title LIKE %s OR b.author LIKE %s)"
            params += [f"%{search}%", f"%{search}%"]
        if filter_status != "All":
            query += " AND b.status=%s"
            params.append(filter_status)
        if filter_cat != "All":
            query += " AND c.category_name=%s"
            params.append(filter_cat)
        query += " ORDER BY b.added_on DESC LIMIT 200"

        books = run_query(query, tuple(params))
        if books:
            import pandas as pd
            df = pd.DataFrame(books)
            df.columns = ["Book ID","Title","Author","ISBN","Publisher","Year","Category","Shelf","Status","Added On"]
            st.dataframe(df, use_container_width=True, hide_index=True)
            st.caption(f"Showing {len(df)} records")
        else:
            st.info("📭 No books found.")

        # ── Edit Book Status ──────────────────────────────────────────────────
        st.markdown("---")
        st.markdown("#### ✏️ Update Book Status")
        with st.form("update_book_status"):
            uc1, uc2, uc3 = st.columns(3)
            book_id_input = uc1.number_input("Book ID", min_value=1, step=1, value=1)
            new_status    = uc2.selectbox("New Status", ["available","issued","lost","maintenance"])
            if uc3.form_submit_button("Update", use_container_width=True):
                run_query(
                    "UPDATE books SET status=%s WHERE book_id=%s",
                    (new_status, book_id_input), fetch=False
                )
                st.success(f"✅ Book ID {book_id_input} status updated to '{new_status}'.")
                st.rerun()
