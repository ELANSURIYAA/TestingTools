import streamlit as st
from db import run_query
import pandas as pd
from datetime import date


def render():
    st.markdown("""
    <div class="page-header">
        <h1>ℹ️ Information Centre</h1>
        <p>Browse available books, member directory, and membership details</p>
    </div>
    """, unsafe_allow_html=True)

    tab_books, tab_members, tab_memberships = st.tabs(
        ["📚 Available Books", "👥 Members Directory", "🎫 Memberships"]
    )

    # ════════════════════════════════════════════════════════════════════════
    # TAB 1 — Available Books
    # ════════════════════════════════════════════════════════════════════════
    with tab_books:
        st.markdown("### 📚 Library Book Catalogue")

        col1, col2, col3, col4 = st.columns(4)
        search     = col1.text_input("🔍 Search Title / Author / ISBN")
        categories = run_query("SELECT category_name FROM categories ORDER BY category_name")
        cat_list   = ["All"] + [c["category_name"] for c in (categories or [])]
        filter_cat = col2.selectbox("Category", cat_list)
        filter_status = col3.selectbox("Status", ["All","available","issued","lost","maintenance"])
        filter_year   = col4.text_input("Year", placeholder="e.g. 2022")

        query  = """
            SELECT b.book_id AS `ID`,
                   b.title   AS `Title`,
                   b.author  AS `Author`,
                   b.isbn    AS `ISBN`,
                   b.publisher AS `Publisher`,
                   b.publication_year AS `Year`,
                   c.category_name    AS `Category`,
                   b.shelf_location   AS `Shelf`,
                   b.status           AS `Status`,
                   b.added_on         AS `Added On`
            FROM books b
            LEFT JOIN categories c ON c.category_id=b.category_id
            WHERE 1=1
        """
        params = []
        if search:
            query += " AND (b.title LIKE %s OR b.author LIKE %s OR b.isbn LIKE %s)"
            params += [f"%{search}%"]*3
        if filter_cat != "All":
            query += " AND c.category_name=%s"
            params.append(filter_cat)
        if filter_status != "All":
            query += " AND b.status=%s"
            params.append(filter_status)
        if filter_year.strip():
            query += " AND b.publication_year=%s"
            params.append(filter_year.strip())
        query += " ORDER BY b.title LIMIT 500"

        books = run_query(query, tuple(params))
        if books:
            df = pd.DataFrame(books)
            # Colour-code status
            def colour_status(val):
                colours = {
                    "available":   "background-color:#d4edda; color:#155724",
                    "issued":      "background-color:#fff3cd; color:#856404",
                    "lost":        "background-color:#f8d7da; color:#721c24",
                    "maintenance": "background-color:#d1ecf1; color:#0c5460",
                }
                return colours.get(val, "")

            styled = df.style.applymap(colour_status, subset=["Status"])
            st.dataframe(styled, use_container_width=True, hide_index=True)

            # Summary counts
            sc1, sc2, sc3, sc4 = st.columns(4)
            status_counts = {r["Status"]: 0 for r in books}
            for r in books:
                status_counts[r["Status"]] = status_counts.get(r["Status"], 0) + 1
            sc1.metric("✅ Available",   status_counts.get("available", 0))
            sc2.metric("📖 Issued",      status_counts.get("issued",    0))
            sc3.metric("❌ Lost",         status_counts.get("lost",      0))
            sc4.metric("🔧 Maintenance", status_counts.get("maintenance",0))
        else:
            st.info("📭 No books found matching the filters.")

    # ════════════════════════════════════════════════════════════════════════
    # TAB 2 — Members Directory
    # ════════════════════════════════════════════════════════════════════════
    with tab_members:
        if st.session_state.role != "admin":
            st.warning("⚠️ Members directory is visible to admins only.")
            return

        st.markdown("### 👥 Member Directory")

        col_s, col_f = st.columns(2)
        m_search = col_s.text_input("🔍 Search Name / Email / Phone")
        m_status = col_f.selectbox("Member Status", ["All","active","inactive","suspended"])

        query  = """
            SELECT m.member_id   AS `ID`,
                   CONCAT(m.first_name,' ',m.last_name) AS `Name`,
                   m.email       AS `Email`,
                   m.phone       AS `Phone`,
                   m.join_date   AS `Join Date`,
                   m.status      AS `Status`,
                   p.plan_name   AS `Plan`,
                   ms.plan_end_date AS `Plan Expiry`,
                   (SELECT COUNT(*) FROM transactions t
                    WHERE t.member_id=m.member_id AND t.status='issued') AS `Books Out`,
                   (SELECT COALESCE(SUM(fine_amount),0) FROM transactions t
                    WHERE t.member_id=m.member_id AND fine_paid=0) AS `Pending Fine (₹)`
            FROM members m
            LEFT JOIN memberships ms ON ms.member_id=m.member_id
            LEFT JOIN membership_plans p ON p.plan_id=ms.plan_id
            WHERE 1=1
        """
        params = []
        if m_search:
            query += " AND (m.first_name LIKE %s OR m.last_name LIKE %s OR m.email LIKE %s OR m.phone LIKE %s)"
            params += [f"%{m_search}%"]*4
        if m_status != "All":
            query += " AND m.status=%s"
            params.append(m_status)
        query += " ORDER BY m.join_date DESC LIMIT 300"

        members = run_query(query, tuple(params))
        if members:
            df = pd.DataFrame(members)
            st.dataframe(df, use_container_width=True, hide_index=True)
            st.caption(f"Total: {len(df)} members")

            # Member status management
            st.markdown("---")
            st.markdown("#### ⚙️ Update Member Status")
            with st.form("update_member_status"):
                uc1, uc2, uc3 = st.columns(3)
                mid_input  = uc1.number_input("Member ID", min_value=1, step=1)
                new_status = uc2.selectbox("New Status", ["active","inactive","suspended"])
                if uc3.form_submit_button("Update Status", use_container_width=True):
                    run_query("UPDATE members SET status=%s WHERE member_id=%s",
                              (new_status, mid_input), fetch=False)
                    st.success(f"✅ Member {mid_input} status → '{new_status}'")
                    st.rerun()
        else:
            st.info("📭 No members found.")

    # ════════════════════════════════════════════════════════════════════════
    # TAB 3 — Memberships
    # ════════════════════════════════════════════════════════════════════════
    with tab_memberships:
        if st.session_state.role != "admin":
            # Member sees only their own
            own = run_query("""
                SELECT p.plan_name, p.duration_days, p.price, p.max_books,
                       ms.plan_start_date, ms.plan_end_date,
                       CASE WHEN ms.plan_end_date >= CURDATE() THEN 'Active' ELSE 'Expired' END AS status
                FROM memberships ms JOIN membership_plans p ON p.plan_id=ms.plan_id
                WHERE ms.member_id=%s
            """, (st.session_state.user_id,))
            if own:
                r = own[0]
                exp_date = r["plan_end_date"]
                days_left = (exp_date - date.today()).days if exp_date else 0
                st.markdown(f"""
                <div style="background:white;border-radius:12px;padding:24px;
                            box-shadow:0 2px 12px rgba(0,0,0,0.08);border-left:5px solid #533483;">
                    <h3>🎫 Your Membership</h3>
                    <p><b>Plan:</b> {r['plan_name']}</p>
                    <p><b>Price:</b> ₹{r['price']}</p>
                    <p><b>Max Books:</b> {r['max_books']}</p>
                    <p><b>Valid:</b> {r['plan_start_date']} → {r['plan_end_date']}</p>
                    <p><b>Days Left:</b> {days_left}</p>
                    <p><b>Status:</b> {'🟢 Active' if r['status']=='Active' else '🔴 Expired'}</p>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.warning("⚠️ No membership found. Contact admin.")
            return

        st.markdown("### 🎫 All Memberships")
        rows = run_query("""
            SELECT m.member_id AS `Member ID`,
                   CONCAT(m.first_name,' ',m.last_name) AS `Name`,
                   p.plan_name AS `Plan`,
                   p.price AS `Price (₹)`,
                   p.max_books AS `Max Books`,
                   ms.plan_start_date AS `Start Date`,
                   ms.plan_end_date   AS `End Date`,
                   CASE WHEN ms.plan_end_date >= CURDATE() THEN 'Active' ELSE 'Expired' END AS `Status`,
                   DATEDIFF(ms.plan_end_date, CURDATE()) AS `Days Remaining`
            FROM memberships ms
            JOIN members m ON m.member_id=ms.member_id
            JOIN membership_plans p ON p.plan_id=ms.plan_id
            ORDER BY ms.plan_end_date DESC
        """)
        if rows:
            df = pd.DataFrame(rows)
            st.dataframe(df, use_container_width=True, hide_index=True)

            # Expiring soon warning
            st.markdown("---")
            st.markdown("#### ⚠️ Expiring Within 7 Days")
            expiring = run_query("""
                SELECT CONCAT(m.first_name,' ',m.last_name) AS name,
                       m.email, m.phone, p.plan_name, ms.plan_end_date,
                       DATEDIFF(ms.plan_end_date, CURDATE()) AS days_left
                FROM memberships ms
                JOIN members m ON m.member_id=ms.member_id
                JOIN membership_plans p ON p.plan_id=ms.plan_id
                WHERE ms.plan_end_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
            """)
            if expiring:
                st.dataframe(pd.DataFrame(expiring), use_container_width=True, hide_index=True)
            else:
                st.success("✅ No memberships expiring in the next 7 days.")
        else:
            st.info("📭 No membership records found.")
