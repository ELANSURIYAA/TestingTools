import streamlit as st
from db import run_query
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import date, timedelta


def render():
    if st.session_state.role != "admin":
        st.warning("⚠️ Analytics is available to admins only.")
        return

    st.markdown("""
    <div class="page-header">
        <h1>📊 Analytics Dashboard</h1>
        <p>Comprehensive insights into library activity, books, members, fines and trends</p>
    </div>
    """, unsafe_allow_html=True)

    # ── Global KPIs ───────────────────────────────────────────────────────────
    st.markdown("### 🏆 Library at a Glance")
    total_books   = run_query("SELECT COUNT(*) AS c FROM books")[0]["c"]
    avail_books   = run_query("SELECT COUNT(*) AS c FROM books WHERE status='available'")[0]["c"]
    issued_books  = run_query("SELECT COUNT(*) AS c FROM books WHERE status='issued'")[0]["c"]
    total_members = run_query("SELECT COUNT(*) AS c FROM members")[0]["c"]
    active_mem    = run_query("SELECT COUNT(*) AS c FROM members WHERE status='active'")[0]["c"]
    total_txns    = run_query("SELECT COUNT(*) AS c FROM transactions")[0]["c"]
    total_fine    = run_query("SELECT COALESCE(SUM(fine_amount),0) AS s FROM transactions")[0]["s"]
    unpaid_fine   = run_query("SELECT COALESCE(SUM(fine_amount),0) AS s FROM transactions WHERE fine_paid=0")[0]["s"]
    overdue_count = run_query("SELECT COUNT(*) AS c FROM transactions WHERE status='issued' AND due_date < CURDATE()")[0]["c"]

    k1,k2,k3,k4,k5 = st.columns(5)
    k1.metric("📚 Total Books",    total_books,   delta=f"{avail_books} available")
    k2.metric("🔄 Issued Now",     issued_books)
    k3.metric("👥 Total Members",  total_members, delta=f"{active_mem} active")
    k4.metric("⚠️ Overdue",        overdue_count)
    k5.metric("💰 Unpaid Fines",   f"₹{unpaid_fine:,.0f}", delta=f"Total ₹{total_fine:,.0f}")

    st.markdown("---")

    # ── Row 1: Book Status Pie + Category Bar ────────────────────────────────
    col_a, col_b = st.columns(2)

    with col_a:
        st.markdown("#### 📊 Books by Status")
        book_status = run_query("SELECT status, COUNT(*) AS count FROM books GROUP BY status")
        if book_status:
            df_bs = pd.DataFrame(book_status)
            fig = px.pie(df_bs, names="status", values="count",
                         color="status",
                         color_discrete_map={
                             "available":"#28a745","issued":"#ffc107",
                             "lost":"#dc3545","maintenance":"#17a2b8"
                         },
                         hole=0.4)
            fig.update_layout(margin=dict(t=20,b=20,l=20,r=20), height=320)
            st.plotly_chart(fig, use_container_width=True)

    with col_b:
        st.markdown("#### 📚 Books by Category")
        cat_books = run_query("""
            SELECT c.category_name AS category, COUNT(b.book_id) AS count
            FROM categories c LEFT JOIN books b ON b.category_id=c.category_id
            GROUP BY c.category_name ORDER BY count DESC
        """)
        if cat_books:
            df_cb = pd.DataFrame(cat_books)
            fig = px.bar(df_cb, x="count", y="category", orientation="h",
                         color="count", color_continuous_scale="Blues",
                         labels={"count":"Books","category":""})
            fig.update_layout(margin=dict(t=20,b=20,l=20,r=20), height=320,
                              coloraxis_showscale=False)
            st.plotly_chart(fig, use_container_width=True)

    st.markdown("---")

    # ── Row 2: Monthly Transactions Line + Member Growth ──────────────────────
    col_c, col_d = st.columns(2)

    with col_c:
        st.markdown("#### 📈 Monthly Issue & Return Trends (Last 12 Months)")
        monthly = run_query("""
            SELECT DATE_FORMAT(issue_date, '%Y-%m') AS month,
                   COUNT(*) AS issued,
                   SUM(CASE WHEN status='returned' THEN 1 ELSE 0 END) AS returned
            FROM transactions
            WHERE issue_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
            GROUP BY month ORDER BY month
        """)
        if monthly:
            df_m = pd.DataFrame(monthly)
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=df_m["month"], y=df_m["issued"],
                                     mode="lines+markers", name="Issued",
                                     line=dict(color="#0f3460", width=2)))
            fig.add_trace(go.Scatter(x=df_m["month"], y=df_m["returned"],
                                     mode="lines+markers", name="Returned",
                                     line=dict(color="#28a745", width=2)))
            fig.update_layout(margin=dict(t=20,b=20,l=20,r=20), height=300,
                              legend=dict(orientation="h", y=1.1))
            st.plotly_chart(fig, use_container_width=True)

    with col_d:
        st.markdown("#### 👥 Member Registrations (Last 12 Months)")
        mem_growth = run_query("""
            SELECT DATE_FORMAT(join_date, '%Y-%m') AS month, COUNT(*) AS new_members
            FROM members
            WHERE join_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
            GROUP BY month ORDER BY month
        """)
        if mem_growth:
            df_mg = pd.DataFrame(mem_growth)
            fig = px.bar(df_mg, x="month", y="new_members",
                         color="new_members", color_continuous_scale="Purples",
                         labels={"month":"Month","new_members":"New Members"})
            fig.update_layout(margin=dict(t=20,b=20,l=20,r=20), height=300,
                              coloraxis_showscale=False)
            st.plotly_chart(fig, use_container_width=True)

    st.markdown("---")

    # ── Row 3: Fine Analysis + Membership Plan Distribution ──────────────────
    col_e, col_f = st.columns(2)

    with col_e:
        st.markdown("#### 💰 Monthly Fine Collection")
        fine_monthly = run_query("""
            SELECT DATE_FORMAT(return_date, '%Y-%m') AS month,
                   SUM(fine_amount) AS total_fine,
                   SUM(CASE WHEN fine_paid=1 THEN fine_amount ELSE 0 END) AS collected
            FROM transactions
            WHERE return_date IS NOT NULL AND fine_amount > 0
              AND return_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
            GROUP BY month ORDER BY month
        """)
        if fine_monthly:
            df_f = pd.DataFrame(fine_monthly)
            fig = go.Figure()
            fig.add_trace(go.Bar(x=df_f["month"], y=df_f["total_fine"],
                                 name="Total Fine", marker_color="#dc3545"))
            fig.add_trace(go.Bar(x=df_f["month"], y=df_f["collected"],
                                 name="Collected",  marker_color="#28a745"))
            fig.update_layout(barmode="group", margin=dict(t=20,b=20,l=20,r=20),
                              height=300, legend=dict(orientation="h", y=1.1))
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No fine data available.")

    with col_f:
        st.markdown("#### 🎫 Membership Plan Distribution")
        plan_dist = run_query("""
            SELECT p.plan_name, COUNT(ms.membership_id) AS count
            FROM membership_plans p
            LEFT JOIN memberships ms ON ms.plan_id=p.plan_id
            GROUP BY p.plan_name
        """)
        if plan_dist:
            df_p = pd.DataFrame(plan_dist)
            fig = px.pie(df_p, names="plan_name", values="count",
                         color_discrete_sequence=px.colors.qualitative.Set2,
                         hole=0.35)
            fig.update_layout(margin=dict(t=20,b=20,l=20,r=20), height=300)
            st.plotly_chart(fig, use_container_width=True)

    st.markdown("---")

    # ── Row 4: Top Borrowed Books + Top Members ───────────────────────────────
    col_g, col_h = st.columns(2)

    with col_g:
        st.markdown("#### 🏅 Top 10 Most Borrowed Books")
        top_books = run_query("""
            SELECT b.title, b.author, COUNT(t.transaction_id) AS borrow_count
            FROM transactions t JOIN books b ON b.book_id=t.book_id
            GROUP BY b.book_id ORDER BY borrow_count DESC LIMIT 10
        """)
        if top_books:
            df_tb = pd.DataFrame(top_books)
            fig = px.bar(df_tb, x="borrow_count", y="title", orientation="h",
                         color="borrow_count", color_continuous_scale="Oranges",
                         labels={"borrow_count":"Times Borrowed","title":""})
            fig.update_layout(margin=dict(t=20,b=20,l=20,r=20), height=340,
                              coloraxis_showscale=False)
            st.plotly_chart(fig, use_container_width=True)

    with col_h:
        st.markdown("#### 👑 Top 10 Most Active Members")
        top_mem = run_query("""
            SELECT CONCAT(m.first_name,' ',m.last_name) AS member,
                   COUNT(t.transaction_id) AS total_borrows,
                   COALESCE(SUM(t.fine_amount),0) AS total_fine
            FROM transactions t JOIN members m ON m.member_id=t.member_id
            GROUP BY t.member_id ORDER BY total_borrows DESC LIMIT 10
        """)
        if top_mem:
            df_tm = pd.DataFrame(top_mem)
            df_tm.columns = ["Member","Total Borrows","Total Fine (₹)"]
            st.dataframe(df_tm, use_container_width=True, hide_index=True)

    st.markdown("---")

    # ── Overdue Analysis Table ────────────────────────────────────────────────
    st.markdown("### ⚠️ Overdue Book Details")
    overdue_rows = run_query("""
        SELECT t.transaction_id AS `Txn ID`,
               CONCAT(m.first_name,' ',m.last_name) AS `Member`,
               m.phone AS `Phone`, b.title AS `Book`,
               t.issue_date AS `Issue Date`, t.due_date AS `Due Date`,
               DATEDIFF(CURDATE(), t.due_date) AS `Overdue Days`,
               DATEDIFF(CURDATE(), t.due_date) * 10 AS `Fine (₹)`
        FROM transactions t
        JOIN members m ON m.member_id=t.member_id
        JOIN books   b ON b.book_id=t.book_id
        WHERE t.status='issued' AND t.due_date < CURDATE()
        ORDER BY `Overdue Days` DESC
    """)
    if overdue_rows:
        df_od = pd.DataFrame(overdue_rows)
        st.dataframe(df_od, use_container_width=True, hide_index=True)
        total_overdue_fine = df_od["Fine (₹)"].sum()
        st.error(f"⚠️ Total overdue fine outstanding: **₹{total_overdue_fine:,.2f}**")
    else:
        st.success("🎉 No overdue books!")

    st.markdown("---")

    # ── Daily Activity Heatmap (last 30 days) ─────────────────────────────────
    st.markdown("### 📅 Issue Activity — Last 30 Days")
    daily = run_query("""
        SELECT issue_date, COUNT(*) AS issues
        FROM transactions
        WHERE issue_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        GROUP BY issue_date ORDER BY issue_date
    """)
    if daily:
        df_d = pd.DataFrame(daily)
        fig = px.bar(df_d, x="issue_date", y="issues",
                     color="issues", color_continuous_scale="Teal",
                     labels={"issue_date":"Date","issues":"Books Issued"})
        fig.update_layout(margin=dict(t=20,b=20,l=20,r=20), height=260,
                          coloraxis_showscale=False)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No issue activity in the last 30 days.")
