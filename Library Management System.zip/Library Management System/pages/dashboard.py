import streamlit as st
from db import run_query
from datetime import date


def render():
    role      = st.session_state.role
    user_name = st.session_state.user_name
    member_id = st.session_state.user_id if role == "member" else None

    st.markdown(f"""
    <div class="page-header">
        <h1>🏠 Dashboard</h1>
        <p>Welcome back, <strong>{user_name}</strong> — {date.today().strftime('%A, %d %B %Y')}</p>
    </div>
    """, unsafe_allow_html=True)

    # ── KPI Row ───────────────────────────────────────────────────────────────
    if role == "admin":
        total_books   = run_query("SELECT COUNT(*) AS c FROM books")[0]["c"]
        avail_books   = run_query("SELECT COUNT(*) AS c FROM books WHERE status='available'")[0]["c"]
        total_members = run_query("SELECT COUNT(*) AS c FROM members WHERE status='active'")[0]["c"]
        active_issues = run_query("SELECT COUNT(*) AS c FROM transactions WHERE status='issued'")[0]["c"]
        overdue       = run_query(
            "SELECT COUNT(*) AS c FROM transactions WHERE status='issued' AND due_date < CURDATE()"
        )[0]["c"]
        total_fine    = run_query(
            "SELECT COALESCE(SUM(fine_amount),0) AS s FROM transactions WHERE fine_paid=0"
        )[0]["s"]

        c1, c2, c3, c4, c5, c6 = st.columns(6)
        c1.metric("📚 Total Books",    total_books)
        c2.metric("✅ Available",       avail_books)
        c3.metric("👥 Active Members", total_members)
        c4.metric("🔄 Issued",         active_issues)
        c5.metric("⚠️ Overdue",        overdue)
        c6.metric("💰 Pending Fine",   f"₹{total_fine:,.2f}")

        st.markdown("---")
        # ── Quick Actions ─────────────────────────────────────────────────────
        st.markdown("### ⚡ Quick Actions")
        qa1, qa2, qa3, qa4, qa5 = st.columns(5)

        if qa1.button("➕ Add New Book",      use_container_width=True):
            st.session_state.page = "add_book"; st.rerun()
        if qa2.button("📤 Issue Book",         use_container_width=True):
            st.session_state.page = "transactions"; st.rerun()
        if qa3.button("📥 Return Book",        use_container_width=True):
            st.session_state.page = "transactions"; st.rerun()
        if qa4.button("ℹ️ View Information",   use_container_width=True):
            st.session_state.page = "information"; st.rerun()
        if qa5.button("📊 Analytics",          use_container_width=True):
            st.session_state.page = "analytics"; st.rerun()

        st.markdown("---")

        # ── Overdue Table ─────────────────────────────────────────────────────
        st.markdown("### ⚠️ Overdue Books")
        overdue_rows = run_query("""
            SELECT t.transaction_id,
                   CONCAT(m.first_name,' ',m.last_name) AS member,
                   m.phone,
                   b.title, b.author,
                   t.issue_date, t.due_date,
                   DATEDIFF(CURDATE(), t.due_date)          AS overdue_days,
                   DATEDIFF(CURDATE(), t.due_date) * 10.00  AS fine_due
            FROM transactions t
            JOIN members m ON m.member_id = t.member_id
            JOIN books   b ON b.book_id   = t.book_id
            WHERE t.status='issued' AND t.due_date < CURDATE()
            ORDER BY overdue_days DESC
            LIMIT 10
        """)
        if overdue_rows:
            import pandas as pd
            df = pd.DataFrame(overdue_rows)
            df.columns = ["Txn ID","Member","Phone","Title","Author","Issue Date","Due Date","Overdue Days","Fine (₹)"]
            st.dataframe(df, use_container_width=True, hide_index=True)
        else:
            st.success("🎉 No overdue books right now!")

        st.markdown("---")

        # ── Register / Assign Membership ──────────────────────────────────────
        st.markdown("### 🆔 Assign Membership to Existing Member")
        members_no_plan = run_query("""
            SELECT m.member_id, CONCAT(m.first_name,' ',m.last_name) AS name
            FROM members m
            LEFT JOIN memberships ms ON ms.member_id = m.member_id
            WHERE ms.membership_id IS NULL AND m.status='active'
        """)
        plans = run_query("SELECT plan_id, plan_name, price, duration_days FROM membership_plans")

        if members_no_plan and plans:
            col_a, col_b, col_c = st.columns(3)
            m_opts = {f"[{r['member_id']}] {r['name']}": r["member_id"] for r in members_no_plan}
            p_opts = {f"{p['plan_name']} — ₹{p['price']}": p["plan_id"] for p in plans}
            sel_m  = col_a.selectbox("Select Member",         list(m_opts.keys()))
            sel_p  = col_b.selectbox("Select Plan",           list(p_opts.keys()))
            if col_c.button("✅ Assign Plan", use_container_width=True):
                mid = m_opts[sel_m]
                pid = p_opts[sel_p]
                run_query("""
                    INSERT INTO memberships (member_id, plan_id, plan_start_date, plan_end_date)
                    VALUES (%s, %s, CURDATE(),
                        DATE_ADD(CURDATE(), INTERVAL (SELECT duration_days FROM membership_plans WHERE plan_id=%s) DAY))
                    ON DUPLICATE KEY UPDATE
                        plan_id=VALUES(plan_id),
                        plan_start_date=CURDATE(),
                        plan_end_date=DATE_ADD(CURDATE(), INTERVAL (SELECT duration_days FROM membership_plans WHERE plan_id=%s) DAY)
                """, (mid, pid, pid, pid), fetch=False)
                st.success("✅ Membership assigned!")
                st.rerun()
        else:
            st.info("ℹ️ All active members already have a membership plan.")

    else:
        # ── Member Dashboard ──────────────────────────────────────────────────
        plan_info = run_query("""
            SELECT p.plan_name, ms.plan_start_date, ms.plan_end_date,
                   CASE WHEN ms.plan_end_date >= CURDATE() THEN 'Active' ELSE 'Expired' END AS status
            FROM memberships ms JOIN membership_plans p ON p.plan_id=ms.plan_id
            WHERE ms.member_id=%s
        """, (member_id,))

        issued = run_query(
            "SELECT COUNT(*) AS c FROM transactions WHERE member_id=%s AND status='issued'", (member_id,)
        )[0]["c"]
        fine = run_query(
            "SELECT COALESCE(SUM(fine_amount),0) AS s FROM transactions WHERE member_id=%s AND fine_paid=0",
            (member_id,)
        )[0]["s"]

        c1, c2, c3 = st.columns(3)
        c1.metric("📖 Books Currently Issued", issued)
        c2.metric("💰 Pending Fine",            f"₹{fine:,.2f}")
        if plan_info:
            p = plan_info[0]
            c3.metric("🎫 Membership", p["plan_name"], delta=p["status"])
        else:
            c3.metric("🎫 Membership", "None")

        st.markdown("---")
        st.markdown("### 📖 My Current Issues")
        my_books = run_query("""
            SELECT b.title, b.author, t.issue_date, t.due_date,
                   CASE WHEN t.due_date < CURDATE() THEN DATEDIFF(CURDATE(),t.due_date)*10 ELSE 0 END AS fine_due
            FROM transactions t JOIN books b ON b.book_id=t.book_id
            WHERE t.member_id=%s AND t.status='issued'
        """, (member_id,))

        if my_books:
            import pandas as pd
            df = pd.DataFrame(my_books)
            df.columns = ["Title","Author","Issue Date","Due Date","Fine (₹)"]
            st.dataframe(df, use_container_width=True, hide_index=True)
        else:
            st.info("📭 No books currently issued to you.")
