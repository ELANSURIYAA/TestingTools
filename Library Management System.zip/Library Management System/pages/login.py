import streamlit as st
import hashlib
from db import run_query

# ─────────────────────────────────────────────────────────────────────────────
# ✅ NO st.set_page_config() here — it lives only in app.py
# ─────────────────────────────────────────────────────────────────────────────

def sha256(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def render():
    st.markdown("""
    <div style="
        background: linear-gradient(135deg,#0f3460,#533483,#e94560);
        min-height: 100vh; display:flex; align-items:center;
        justify-content:center; padding:40px;
        border-radius:16px; margin-bottom:20px;">
        <div style="text-align:center; color:white;">
            <h1 style="font-size:3rem; margin:0;">📚</h1>
            <h1 style="margin:8px 0; font-size:2rem;">Library Management System</h1>
            <p style="opacity:.8; font-size:1rem;">Your smart library portal</p>
        </div>
    </div>
    """, unsafe_allow_html=True)

    col1, col2, col3 = st.columns([1, 1.6, 1])
    with col2:
        tab_admin, tab_member, tab_signup = st.tabs(
            ["🔐 Admin Login", "👤 Login", "✏️ Sign-Up"]
        )

        # ── Admin Login ───────────────────────────────────────────────────────
        with tab_admin:
            st.markdown("### Admin Portal")
            with st.form("admin_login_form"):
                username = st.text_input("Username", placeholder="admin")
                password = st.text_input("Password", type="password", placeholder="••••••••")
                submitted = st.form_submit_button("🔐 Login as Admin", use_container_width=True)

            if submitted:
                if not username or not password:
                    st.warning("Please fill in all fields.")
                else:
                    h = sha256(password)
                    rows = run_query(
                        "SELECT admin_id, full_name FROM admins WHERE username=%s AND password_hash=%s",
                        (username, h),
                    )
                    if rows:
                        st.session_state.logged_in = True
                        st.session_state.role      = "admin"
                        st.session_state.user_id   = rows[0]["admin_id"]
                        st.session_state.user_name = rows[0]["full_name"] or username
                        st.session_state.page      = "dashboard"
                        st.success("✅ Welcome back, Admin!")
                        st.rerun()
                    else:
                        st.error("❌ Invalid credentials.")

        # ── Member Login ──────────────────────────────────────────────────────
        with tab_member:
            st.markdown("### Member Portal")
            with st.form("member_login_form"):
                mem_email = st.text_input("Registered Email", placeholder="you@example.com")
                mem_phone = st.text_input("Phone Number", placeholder="9876543210")
                submitted2 = st.form_submit_button("👤 Login", use_container_width=True)

            if submitted2:
                if not mem_email or not mem_phone:
                    st.warning("Please fill in all fields.")
                else:
                    rows = run_query(
                        """SELECT member_id, first_name, last_name, status
                           FROM members WHERE email=%s AND phone=%s""",
                        (mem_email, mem_phone),
                    )
                    if rows:
                        m = rows[0]
                        if m["status"] == "suspended":
                            st.error("❌ Your account is suspended. Contact admin.")
                        else:
                            st.session_state.logged_in = True
                            st.session_state.role      = "member"
                            st.session_state.user_id   = m["member_id"]
                            st.session_state.user_name = f"{m['first_name']} {m['last_name']}"
                            st.session_state.page      = "dashboard"
                            st.success(f"✅ Welcome, {st.session_state.user_name}!")
                            st.rerun()
                    else:
                        st.error("❌ No account found. Check credentials or sign up.")

        # ── Sign-Up ───────────────────────────────────────────────────────────
        with tab_signup:
            st.markdown("### Create Member Account")
            with st.form("signup_form"):
                c1, c2 = st.columns(2)
                first_name = c1.text_input("First Name *", placeholder="Ravi")
                last_name  = c2.text_input("Last Name *",  placeholder="Kumar")
                email   = st.text_input("Email *",          placeholder="ravi@email.com")
                phone   = st.text_input("Phone *",          placeholder="9876543210")
                address = st.text_area("Address",           placeholder="No. 1, Anna Nagar, Chennai")

                plans = run_query("SELECT plan_id, plan_name, price, duration_days, max_books FROM membership_plans")
                plan_options = {
                    f"{p['plan_name']} — ₹{p['price']} / {p['duration_days']} days (Max {p['max_books']} books)": p["plan_id"]
                    for p in (plans or [])
                }
                selected_plan_label = st.selectbox("Membership Plan *", list(plan_options.keys()))

                submitted3 = st.form_submit_button("✏️ Register", use_container_width=True)

            if submitted3:
                if not first_name or not last_name or not email or not phone:
                    st.warning("Please fill all required (*) fields.")
                else:
                    exists = run_query("SELECT member_id FROM members WHERE email=%s", (email,))
                    if exists:
                        st.error("❌ Email already registered. Please log in.")
                    else:
                        res = run_query(
                            """INSERT INTO members (first_name, last_name, email, phone, address)
                               VALUES (%s,%s,%s,%s,%s)""",
                            (first_name, last_name, email, phone, address),
                            fetch=False,
                        )
                        if res and res["last_id"]:
                            member_id = res["last_id"]
                            plan_id   = plan_options[selected_plan_label]
                            run_query(
                                """INSERT INTO memberships (member_id, plan_id, plan_start_date, plan_end_date)
                                   VALUES (%s, %s, CURDATE(),
                                       DATE_ADD(CURDATE(), INTERVAL
                                           (SELECT duration_days FROM membership_plans WHERE plan_id=%s) DAY))""",
                                (member_id, plan_id, plan_id),
                                fetch=False,
                            )
                            st.success("✅ Account created! Please log in via Member Login.")
                        else:
                            st.error("❌ Registration failed. Try again.")