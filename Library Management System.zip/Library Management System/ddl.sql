-- ================================================================================
-- Library Management System — COMPLETE DDL
-- Database : mybala
-- MySQL 8.x
-- Run this entire script in MySQL Workbench or CLI: mysql -u root -p < ddl.sql
-- ================================================================================

CREATE DATABASE IF NOT EXISTS mybala
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE mybala;

-- ─────────────────────────────────────────────────────────────────────────────
-- 1. ADMINS
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS admins (
    admin_id        INT            NOT NULL AUTO_INCREMENT,
    username        VARCHAR(50)    NOT NULL UNIQUE,
    password_hash   VARCHAR(64)    NOT NULL,          -- SHA-256 hex string
    full_name       VARCHAR(100),
    email           VARCHAR(120),
    created_at      DATETIME       DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (admin_id)
);

-- Default admin: username=admin | password=admin123
INSERT IGNORE INTO admins (username, password_hash, full_name, email)
VALUES (
    'admin',
    '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9',
    'System Administrator',
    'admin@library.com'
);


-- ─────────────────────────────────────────────────────────────────────────────
-- 2. CATEGORIES
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS categories (
    category_id     INT            NOT NULL AUTO_INCREMENT,
    category_name   VARCHAR(80)    NOT NULL UNIQUE,
    description     TEXT,
    PRIMARY KEY (category_id)
);

INSERT IGNORE INTO categories (category_name) VALUES
    ('Fiction'), ('Non-Fiction'), ('Science'), ('Technology'),
    ('History'), ('Biography'), ('Self-Help'), ('Children'),
    ('Reference'), ('Comics');


-- ─────────────────────────────────────────────────────────────────────────────
-- 3. BOOKS
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS books (
    book_id             INT             NOT NULL AUTO_INCREMENT,
    title               VARCHAR(255)    NOT NULL,
    author              VARCHAR(150)    NOT NULL,
    isbn                VARCHAR(20),
    publisher           VARCHAR(120),
    publication_year    YEAR,
    category_id         INT,
    shelf_location      VARCHAR(30),
    description         TEXT,
    status              ENUM('available','issued','lost','maintenance')
                        NOT NULL DEFAULT 'available',
    added_on            DATE            DEFAULT (CURDATE()),
    PRIMARY KEY (book_id),
    FOREIGN KEY (category_id) REFERENCES categories(category_id)
        ON DELETE SET NULL
);


-- ─────────────────────────────────────────────────────────────────────────────
-- 4. MEMBERS
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS members (
    member_id       INT             NOT NULL AUTO_INCREMENT,
    first_name      VARCHAR(60)     NOT NULL,
    last_name       VARCHAR(60)     NOT NULL,
    email           VARCHAR(120)    UNIQUE,
    phone           VARCHAR(20),
    address         TEXT,
    join_date       DATE            DEFAULT (CURDATE()),
    status          ENUM('active','inactive','suspended')
                    NOT NULL DEFAULT 'active',
    PRIMARY KEY (member_id)
);


-- ─────────────────────────────────────────────────────────────────────────────
-- 5. MEMBERSHIP_PLANS
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS membership_plans (
    plan_id         INT             NOT NULL AUTO_INCREMENT,
    plan_name       VARCHAR(80)     NOT NULL UNIQUE,
    duration_days   INT             NOT NULL,
    price           DECIMAL(8,2)    NOT NULL,
    max_books       INT             DEFAULT 3,
    description     TEXT,
    PRIMARY KEY (plan_id)
);

INSERT IGNORE INTO membership_plans (plan_name, duration_days, price, max_books, description) VALUES
    ('Basic Monthly',      30,   99.00, 2, 'Borrow up to 2 books for 1 month'),
    ('Standard Quarterly', 90,  249.00, 4, 'Borrow up to 4 books for 3 months'),
    ('Premium Annual',    365,  799.00, 8, 'Borrow up to 8 books for 1 year');


-- ─────────────────────────────────────────────────────────────────────────────
-- 6. MEMBERSHIPS
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS memberships (
    membership_id       INT     NOT NULL AUTO_INCREMENT,
    member_id           INT     NOT NULL,
    plan_id             INT     NOT NULL,
    plan_start_date     DATE    NOT NULL,
    plan_end_date       DATE    NOT NULL,
    PRIMARY KEY (membership_id),
    UNIQUE KEY uq_member_plan (member_id),
    FOREIGN KEY (member_id) REFERENCES members(member_id)  ON DELETE CASCADE,
    FOREIGN KEY (plan_id)   REFERENCES membership_plans(plan_id)
);


-- ─────────────────────────────────────────────────────────────────────────────
-- 7. TRANSACTIONS
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS transactions (
    transaction_id  INT             NOT NULL AUTO_INCREMENT,
    member_id       INT             NOT NULL,
    book_id         INT             NOT NULL,
    issue_date      DATE            NOT NULL DEFAULT (CURDATE()),
    due_date        DATE            NOT NULL,
    return_date     DATE,
    status          ENUM('issued','returned','lost')
                    NOT NULL DEFAULT 'issued',
    fine_amount     DECIMAL(8,2)    DEFAULT 0.00,
    fine_paid       TINYINT(1)      DEFAULT 0,
    notes           TEXT,
    PRIMARY KEY (transaction_id),
    FOREIGN KEY (member_id) REFERENCES members(member_id),
    FOREIGN KEY (book_id)   REFERENCES books(book_id)
);


-- ─────────────────────────────────────────────────────────────────────────────
-- VIEWS
-- ─────────────────────────────────────────────────────────────────────────────

CREATE OR REPLACE VIEW v_active_issues AS
    SELECT t.transaction_id,
           CONCAT(m.first_name,' ',m.last_name) AS member_name,
           m.phone, m.email,
           b.title, b.author,
           t.issue_date, t.due_date,
           DATEDIFF(CURDATE(), t.due_date)         AS overdue_days,
           GREATEST(0, DATEDIFF(CURDATE(), t.due_date)) * 10.00 AS fine_due
    FROM transactions t
    JOIN members m ON m.member_id = t.member_id
    JOIN books   b ON b.book_id   = t.book_id
    WHERE t.status = 'issued';


CREATE OR REPLACE VIEW v_member_plans AS
    SELECT m.member_id,
           CONCAT(m.first_name,' ',m.last_name) AS member_name,
           p.plan_name,
           ms.plan_start_date, ms.plan_end_date,
           CASE WHEN ms.plan_end_date >= CURDATE() THEN 'Active' ELSE 'Expired' END AS plan_status
    FROM members m
    LEFT JOIN memberships      ms ON ms.member_id = m.member_id
    LEFT JOIN membership_plans  p ON p.plan_id    = ms.plan_id;


-- ─────────────────────────────────────────────────────────────────────────────
-- SAMPLE DATA (optional — remove if not needed)
-- ─────────────────────────────────────────────────────────────────────────────

INSERT IGNORE INTO books (title, author, isbn, publisher, publication_year, category_id, shelf_location, status) VALUES
('The Alchemist',            'Paulo Coelho',     '9780062315007', 'HarperOne',       1988, 1, 'A-01', 'available'),
('Atomic Habits',            'James Clear',      '9780735211292', 'Avery',           2018, 7, 'B-03', 'available'),
('Sapiens',                  'Yuval Noah Harari','9780062316097', 'Harper Perennial', 2015, 5, 'C-07', 'available'),
('Clean Code',               'Robert C. Martin', '9780132350884', 'Prentice Hall',   2008, 4, 'D-02', 'available'),
('Harry Potter & Sorcerers Stone','J.K. Rowling','9780439708180','Scholastic',       1997, 1, 'A-10', 'available'),
('Wings of Fire',            'APJ Abdul Kalam',  '9788173711466', 'Universities Press',1999,6,'E-05','available'),
('Rich Dad Poor Dad',        'Robert Kiyosaki',  '9781612680194', 'Plata Publishing', 1997, 7, 'B-08', 'available'),
('The Python Cookbook',      'David Beazley',    '9781449340377', "O'Reilly",        2013, 4, 'D-11', 'available');


INSERT IGNORE INTO members (first_name, last_name, email, phone, address) VALUES
('Arjun',   'Sharma',    'arjun@email.com',   '9876543210', '12, Gandhi Nagar, Chennai'),
('Priya',   'Rajan',     'priya@email.com',   '9123456780', '45, Anna Salai, Coimbatore'),
('Karthik', 'Murugan',   'karthik@email.com', '9988776655', '78, Kamarajar St, Madurai'),
('Deepa',   'Sundaram',  'deepa@email.com',   '9871234567', '22, Nehru Road, Trichy');


INSERT IGNORE INTO memberships (member_id, plan_id, plan_start_date, plan_end_date)
SELECT m.member_id, 1,
       CURDATE(),
       DATE_ADD(CURDATE(), INTERVAL 30 DAY)
FROM members m
WHERE NOT EXISTS (
    SELECT 1 FROM memberships ms WHERE ms.member_id = m.member_id
)
LIMIT 4;


-- ─────────────────────────────────────────────────────────────────────────────
-- VERIFY
-- ─────────────────────────────────────────────────────────────────────────────
SELECT 'admins'          AS tbl, COUNT(*) AS rows FROM admins
UNION ALL SELECT 'categories',   COUNT(*) FROM categories
UNION ALL SELECT 'books',        COUNT(*) FROM books
UNION ALL SELECT 'members',      COUNT(*) FROM members
UNION ALL SELECT 'membership_plans', COUNT(*) FROM membership_plans
UNION ALL SELECT 'memberships',  COUNT(*) FROM memberships
UNION ALL SELECT 'transactions', COUNT(*) FROM transactions;
